//import createHistory from 'history/createBrowserHistory';

//export default createHistory();

//import { createBrowserHistory } from 'history';

//export default createBrowserHistory();

import { createBrowserHistory } from 'history';

export default createBrowserHistory();