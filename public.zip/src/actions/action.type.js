export const GET_ALL_UOM = 'get_all_uom';
export const GET_ALL_ATTRIBUTES = 'get_all_attributes';
export const GET_ALL_ATTRIBUTE_VALUE = 'get_all_attribute_value';
export const GET_ALL_SUPPLIERS = 'get_all_suppliers';
export const GET_ALL_BUSINESS_TYPE_DIVISION = 'get_all_business_type_division';
export const GET_ALL_CUSTOMERS = 'get_all_customers';
