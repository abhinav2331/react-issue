import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
    return (
        <section className="register_wrapper">
            <h1>This is home page.</h1>
            <Link to="/varification/7fbd735e-d3df-4090-9776-d055d7dfb4fa">Go to page</Link>
        </section>
        )
}