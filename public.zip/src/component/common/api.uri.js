export const API_URI = 'http://api.worx4khushi.com/api';

export const API_URI_TOKEN = "http://api.worx4khushi.com";
