import React from "react";

function Dashboardhome() {
    return (
        
            <div>
                May be it home
            </div>                        
                    
    );
}

export default Dashboardhome;